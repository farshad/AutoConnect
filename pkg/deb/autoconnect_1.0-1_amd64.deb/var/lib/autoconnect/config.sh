#!/bin/sh

#########################################
#        Dont Modify This File          #              
#########################################

alias_array=()
declare -A arr
